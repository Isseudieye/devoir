package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class ImpleMysql implements IPersonne<Personne>{


    private Connection connection;

    public ImplCompteMysql() {
        this.connection = new BD().getConnection();
    }
    @Override
    public void getAllEmploye() {

    }

    @Override
    public void getAllDirecteur() {

    }

    @Override
    public void addPersonne() {

    }

    @Override
    public void addPersonne(Personne personne) throws SQLException {
        Boolean result= personne instanceof Employe;
        String choix = (result) ? "salaire";
        String sql = "INSERT INTO personne (nom,prenom,adresse,"+choix+") values (?,?,?,?)";
        PreparedStatement statement= connection.prepareStatement(sql);
        statement.setString(1,personne.getNom());
        statement.setString(2,personne.getPrenom());
        statement.setString(3,personne.getAdresse());
        statement.setInt(4, ((Employe) personne).getSalaire());

        statement.executeUpdate();
    }

    @Override
    public void DeleteByMatricule() {

    }

    @Override
    public void UpdatePersonne(int id,Personne personne) throws SQLException {
        Boolean result= personne instanceof Directeur;
        String choix = (result) ? "salaire";

        String sql = "Update personnne SET nom = ? , prenom = ? " +
                ", adresse = ?, "+choix+" = ? where id= ?";

        System.out.println(sql);
        PreparedStatement statement= connection.prepareStatement(sql);
        statement.setString(1,personne.getNom());
        statement.setString(2,personne.getPrenom());
        statement.setString(3,personne.getAdresse());
        statement.setInt(4, ((Employe) personne).getSalaire());
    }
}
