package model;

public interface IPersonne<P> {
    void getAllEmploye();
    void getAllDirecteur();
    void addPersonne();
    void DeleteByMatricule();
    void UpdatePersonne();
}
