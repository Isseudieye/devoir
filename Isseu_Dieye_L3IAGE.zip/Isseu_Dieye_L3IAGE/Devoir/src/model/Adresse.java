package model;

public enum Adresse {
    Dakar, Thies, Louga;
}
