package model;

public class Directeur extends Personne implements IPersonne<P> {
    private String matricule;

    public Directeur(int id, String nom, String prenom, String adresse) {
        super();
        this.matricule = genererMatricule();
    }
    private String genererMatricule() {
        return prenom.toUpperCase() + "000" + nom.length();

    }
    public String getMatricule() {
        return matricule;
    }

    public void setMatricule(String matricule) {
        this.matricule = matricule;
    }

    @Override
    public void getAllEmploye() {

    }

    @Override
    public void getAllDirecteur() {

    }

    @Override
    public void addPersonne() {

    }

    @Override
    public void DeleteByMatricule() {

    }

    @Override
    public void UpdatePersonne() {

    }

    @Override
    public String toString() {
        return "Directeur{" +
                "matricule='" + matricule + '\'' +
                '}';
    }
}
