package model;

import java.util.Collections;
import java.util.Set;

public class Employe extends Personne implements IPersonne<P> {
    private int salaire;
    private Set<String> zone;

    public Employe(int id, String nom, String prenom, String adresse, int salaire, Set<String> zone) {
        super();
        this.salaire = salaire;
        this.zone = zone;

    }

    public Employe(String number, String mbengue, String adja, String thies, Set<String> zone) {
        super();

    }


    public int getSalaire() {
        return salaire;
    }

    public void setSalaire(int salaire) {
        this.salaire = salaire;
    }

    public String getZone() {
        return zone.toString();
    }

    public void setZone(String zone) {
        this.zone = Collections.singleton(zone);
    }

    @Override
    public void getAllEmploye() {

    }

    @Override
    public void getAllDirecteur() {

    }

    @Override
    public void addPersonne() {

    }

    @Override
    public void DeleteByMatricule() {

    }

    @Override
    public void UpdatePersonne() {

    }

    @Override
    public String toString() {
        return "Employe{" +
                "salaire=" + salaire +
                ", zone='" + zone + '\'' +
                '}';
    }
}
