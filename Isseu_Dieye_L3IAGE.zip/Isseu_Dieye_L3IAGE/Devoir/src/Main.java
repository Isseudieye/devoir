import model.Adresse;
import model.Employe;
import model.Personne;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class Main {
    public static void main(String[] args) {
        ArrayList<Personne> personnes = new ArrayList<>();

        personnes.add(new Personne("1", "DIEYE", "Isseu", Adresse.Dakar));
        personnes.add(new Personne("2", "MBENGUE", "ADJA", Adresse.Thies));
        personnes.add(new Personne("3", "DIOP", "FATOU", Adresse.Louga));

        Set<String> zone = new HashSet<>(Arrays.asList("PA", "Mbao"));
        personnes.add(new Employe("2", "MBENGUE", "ADJA", "Thies", zone));

        for (Personne personne : personnes) {
            System.out.println(personne.toString());
        }
    }
}